{{View::make("partials.header")}}
<title>CRUD | Create</title>
{{View::make("partials.navbar")}}
<div class="container-fluid mid-section">
    <h5 class="bg-warning text-light text-center my-2 p-2 mb-3">Updata Contact Form</h5>
    <form action="/update/{{$data->id}}" method="post">
        @csrf
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Full Name" value="{{$data->name}}">
            @error('name')
                 <p class="text-danger">{{$message}}</p>
                @enderror
        </div>
        <div class="row">
            <div class="col-sm-6 mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter Email Address" value="{{$data->email}}">
                @error('email')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
            <div class="col-sm-6 mb-3">
                <label>Phone</label>
                <input type="phone" name="phone" class="form-control" placeholder="Enter Phone Number" value="{{$data->phone}}">
                @error('phone')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 mb-3">
                <label>Designation</label>
                <input type="text" name="dsg" class="form-control" placeholder="Enter Designation" value="{{$data->dsg}}">
                @error('dsg')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
            <div class="col-sm-6 mb-3">
                <label>Salary</label>
                <input type="number" name="salary" class="form-control" placeholder="Enter Your Salary" value="{{$data->salary}}">
                @error('dsg')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 mb-3">
                <label>City</label>
                <input type="text" name="city" class="form-control" placeholder="Enter City" value="{{$data->city}}">
                @error('city')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
            <div class="col-sm-6 mb-3">
                <label>State</label>
                <input type="text" name="state" class="form-control" placeholder="Enter State" value="{{$data->state}}">
                @error('state')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
        </div>
          <button class="btn btn-warning text-light w-100" type="submit">Update</button>
    </form>
</div>

{{View::make("partials.footer")}} 