{{View::make("partials.header")}}
<title>CRUD | Home</title>
{{View::make("partials.navbar")}}
<div class="container-fluid mid-section">
    <h5 class="text-center bg-warning text-light p-2 my-2">Contact Form</h5>
    <table class="table table-bordered table-stripred table-hover">
        <thead>
            <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Designation</th>
                <th>Salary</th>
                <th>City</th>
                <th>State</th>
                <th>Edit</th>
                <th>Delete</th>
            </tr>
        </thead>
        <tbody>
             @foreach ($data as $item)
             <tr>
                <td>{{$item->id}}</td>
                <td>{{$item->name}}</td>
                <td>{{$item->email}}</td>
                <td>{{$item->phone}}</td>
                <td>{{$item->dsg}}</td>
                <td>{{$item->salary}}</td>
                <td>{{$item->city}}</td>
                <td>{{$item->state}}</td>
                <td><a href="/edit/{{$item->id}}"><span class="material-symbols-outlined text-primary">edit</span></a></td>
                <td><a href="/destroy/{{$item->id}}"><span class="material-symbols-outlined text-danger">delete</span></a></td>
            </tr>
             @endforeach
        </tbody>
    </table>
</div>
{{View::make("partials.footer")}}