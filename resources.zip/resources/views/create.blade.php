{{View::make("partials.header")}} 
<title>CRUD | Create</title>
{{View::make("partials.navbar")}}
<div class="container-fluid mid-section">
    <h5 class="bg-warning text-light text-center my-2 p-2 mb-3">Create Contact List</h5>
    <form action="/store" method="post">
        @csrf
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="name" class="form-control" placeholder="Enter Full Name ">
            @error('name')
                 <p class="text-danger">{{$message}}</p>
                @enderror
        </div>
        <div class="row">
            <div class="col-sm-6 mb-3">
                <label>Email</label>
                <input type="email" name="email" class="form-control" placeholder="Enter Email Address">
                @error('email')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
            <div class="col-sm-6 mb-3">
                <label>Phone</label>
                <input type="phone" name="phone" class="form-control" placeholder="Enter Phone Number">
                @error('phone')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 mb-3">
                <label>Designation</label>
                <input type="text" name="dsg" class="form-control" placeholder="Enter Designation">
                @error('dsg')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
            <div class="col-sm-6 mb-3">
                <label>Salary</label>
                <input type="number" name="salary" class="form-control" placeholder="Enter Your Salary">
                @error('dsg')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
        </div>
        <div class="row">
            <div class="col-sm-6 mb-3">
                <label>City</label>
                <input type="text" name="city" class="form-control" placeholder="Enter City">
                @error('city')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
            <div class="col-sm-6 mb-3">
                <label>State</label>
                <input type="text" name="state" class="form-control" placeholder="Enter State">
                @error('state')
                 <p class="text-danger">{{$message}}</p>
                @enderror
            </div>
        </div>
          <button class="btn btn-warning text-light w-100" type="submit">Submit</button>
    </form>
</div>

{{View::make("partials.footer")}} 