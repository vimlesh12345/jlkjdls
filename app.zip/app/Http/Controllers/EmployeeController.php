<?php
namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\Employees;

class EmployeeController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function __construct(private Employees $employee)
        {
            
        }
    public function index()
    {   
        $data=$this->employee->latest()->get();
        return view("index",compact('data'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        return view("create");
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {   
        $request->validate([
        'name'=>'required',
        'email'=>'required',
        'phone'=>'required',
        'dsg'=>'required',
        'salary'=>'required',
        'city'=>'required',
        'state'=>'required'
        ]);
        $this->employee->create([
           'name'=>$request->name,   
           'email'=>$request->email,
           'phone'=>$request->phone,
           'dsg'=>$request->dsg,
           'salary'=>$request->salary,
           'city'=>$request->city,
           'state'=>$request->state
        ]);
        return redirect("/");
    }

    /**
     * Display the specified resource.
     */
    public function search(Request $request)
    {
        $data = $this->employee->where('city',$request->search)->orwhere
        ('state',$request->search)->orwhere('name',"like","%$request->search%")
        ->orwhere('dsg',"like","%$request->search%")->orwhere('phone',"like","%$request->search%")->orwhere
        ('email',"like","%$request->search%")->get();
    return view("index",compact('data'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $data=$this->employee->find($id);
        return view("edit",compact('data'));
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $request->validate([
            'name'=>'required',
            'email'=>'required',
            'phone'=>'required',
            'dsg'=>'required',
            'salary'=>'required',
            'city'=>'required',
            'state'=>'required'
            ]);
            $this->employee->find($id)->update([
               'name'=>$request->name,   
               'email'=>$request->email,
               'phone'=>$request->phone,
               'dsg'=>$request->dsg,
               'salary'=>$request->salary,
               'city'=>$request->city,
               'state'=>$request->state
            ]);
            return redirect("/");  
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $this->employee->find($id)->delete();
        return redirect("/");
    }
}
